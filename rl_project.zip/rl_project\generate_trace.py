import csv
import random

# We need 500 steps (default max_steps)
with open('sample_trace.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    # Header: step, queue0 (Voice), queue1 (Video), queue2 (Web), queue3 (Bulk)
    writer.writerow(['step', 'q0', 'q1', 'q2', 'q3'])
    
    for step in range(500):
        # Default low traffic
        q0, q1, q2, q3 = 0, 0, 0, 0
        
        # Add random normal traffic (0 or 1 packet usually)
        if random.random() > 0.5: q0 += 1
        if random.random() > 0.4: q1 += 1
        if random.random() > 0.6: q2 += 1
        if random.random() > 0.7: q3 += 1
        
        # Massive burst of Voice (q0) traffic around step 100
        if 95 < step < 105:
            q0 += 5
            
        # Massive burst of Bulk (q3) traffic around step 300
        if 290 < step < 310:
            q3 += 10
            
        writer.writerow([step, q0, q1, q2, q3])

print("Created sample_trace.csv with 500 steps of traffic!")
