# Reinforcement Learning-based Network Packet Scheduling

A production-ready Python implementation demonstrating how Deep Reinforcement Learning (DQN) outperforms traditional scheduling algorithms in minimizing latency and packet loss in network systems.

## Project Structure

```
rl_packet_scheduler/
├── main.py          # Entry point — CLI with argparse, orchestrates full pipeline
├── env.py           # Custom Gymnasium environment (PacketSchedulerEnv)
├── train.py         # DQN training pipeline with Stable-Baselines3
├── evaluate.py      # Evaluation & comparison across traffic loads
├── baselines.py     # FIFO, Round Robin, Strict Priority schedulers
├── visualize.py     # Publication-quality plotting (latency, drop rate, training curves)
├── utils.py         # Logging, seeding, config management, CSV export
├── requirements.txt # Python dependencies
├── README.md        # This file
├── models/          # Saved DQN models (created at runtime)
├── results/         # CSV results & logs (created at runtime)
└── figures/         # PNG figures (created at runtime)
```

## Installation

### 1. Create a virtual environment (recommended)

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

Or install manually:

```bash
pip install gymnasium stable-baselines3 matplotlib numpy
```

## How to Run

### Full Pipeline (Train + Evaluate + Plot)

```bash
python main.py
```

### Quick Demo (no training needed)

```bash
python main.py --demo
```

### Train Only

```bash
python main.py --train-only --timesteps 200000
```

### Evaluate Only (requires a trained model)

```bash
python main.py --eval-only
```

### Custom Parameters

```bash
python main.py --timesteps 150000 --lr 0.0005 --gamma 0.99 --episodes 20 --seed 123
```

### Custom Arrival Rates

```bash
python main.py --arrival-rates 0.2 0.4 0.6 0.8 1.0 1.2
```

## Command-Line Arguments

| Argument | Default | Description |
|---|---|---|
| `--train-only` | — | Only train (skip evaluation) |
| `--eval-only` | — | Only evaluate (needs trained model) |
| `--demo` | — | Quick demo with Round Robin |
| `--timesteps` | 100000 | Total DQN training timesteps |
| `--lr` | 0.001 | Learning rate |
| `--gamma` | 0.95 | Discount factor |
| `--batch-size` | 64 | Training batch size |
| `--buffer-size` | 50000 | Replay buffer size |
| `--arrival-rate` | 0.6 | Training arrival rate |
| `--max-steps` | 500 | Max steps per episode |
| `--max-queue-len` | 20 | Queue capacity |
| `--episodes` | 10 | Eval episodes per config |
| `--arrival-rates` | 0.3 0.45 0.6 0.75 0.9 | Rates to benchmark |
| `--seed` | 42 | Random seed |
| `--model-path` | models/dqn_scheduler | Model save/load path |
| `--results-dir` | results | Results output directory |
| `--figures-dir` | figures | Figures output directory |

## Environment Design

The `PacketSchedulerEnv` simulates a network router with 4 priority queues:

| Queue | Traffic Class | Urgency Weight |
|-------|--------------|----------------|
| 0 | Voice | 4.0 (highest) |
| 1 | Video | 3.0 |
| 2 | Web | 2.0 |
| 3 | Bulk | 1.0 (lowest) |

**State Space**: `[normalized_queue_lengths (4), normalized_oldest_packet_ages (4)]`

**Action Space**: `Discrete(4)` — select which queue to serve

**Reward**: `urgency_weight - 0.3 × latency - 0.1 × drops - 0.5 × idle`

## Output Files

After running the full pipeline:

- `figures/latency_comparison.png` — Latency vs arrival rate comparison
- `figures/drop_rate_comparison.png` — Drop rate vs arrival rate comparison
- `figures/training_reward.png` — DQN training reward curve
- `figures/training_latency.png` — Latency improvement during training
- `figures/training_drop_rate.png` — Drop rate during training
- `results/avg_latency_comparison.csv` — Raw latency data
- `results/drop_rate_comparison.csv` — Raw drop rate data
- `results/experiment.log` — Full experiment log
- `models/dqn_scheduler.zip` — Trained DQN model

## License

MIT License — free for academic and commercial use.
