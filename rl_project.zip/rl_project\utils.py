"""
utils.py — Utility Functions
==============================

Provides helper functions for:
    - Logging setup and configuration
    - Results I/O (CSV export)
    - Configuration management
    - Reproducibility (seeding)
"""

import os
import csv
import json
import logging
import random
from datetime import datetime
from typing import Dict, List, Any, Optional

import numpy as np

# ─── Default Hyperparameters ────────────────────────────────────────

DEFAULT_CONFIG: Dict[str, Any] = {
    # Environment
    "n_queues": 4,
    "max_queue_len": 20,
    "arrival_rate": 0.6,
    "link_speed": 2,
    "max_steps": 500,
    "max_age_norm": 50.0,
    "latency_penalty_coeff": 0.3,
    "drop_penalty_coeff": 0.1,
    "idle_penalty": 0.5,
    "use_class_rates": False,

    # Training
    "total_timesteps": 100_000,
    "learning_rate": 1e-3,
    "buffer_size": 50_000,
    "learning_starts": 1000,
    "batch_size": 64,
    "gamma": 0.95,
    "train_freq": 4,
    "target_update_interval": 500,
    "exploration_fraction": 0.3,
    "exploration_final_eps": 0.05,

    # Evaluation
    "n_eval_episodes": 10,
    "arrival_rates": [0.3, 0.45, 0.6, 0.75, 0.9],

    # Paths
    "model_save_path": "models/dqn_scheduler",
    "results_dir": "results",
    "figures_dir": "figures",
    "log_file": "results/experiment.log",
}


# ─── Logging Setup ──────────────────────────────────────────────────

def setup_logging(
    log_file: Optional[str] = None,
    level: int = logging.INFO,
) -> logging.Logger:
    """
    Configure and return a logger that writes to both console and file.

    Args:
        log_file: Path to the log file. If None, uses default from config.
        level: Logging level (default: INFO).

    Returns:
        Configured Logger instance.
    """
    if log_file is None:
        log_file = DEFAULT_CONFIG["log_file"]

    # Ensure directory exists
    os.makedirs(os.path.dirname(log_file), exist_ok=True)

    logger = logging.getLogger("rl_packet_scheduler")
    logger.setLevel(level)

    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_fmt = logging.Formatter(
        "[%(asctime)s] %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )
    console_handler.setFormatter(console_fmt)
    logger.addHandler(console_handler)

    # File handler
    file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
    file_handler.setLevel(level)
    file_fmt = logging.Formatter(
        "[%(asctime)s] %(levelname)-8s %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(file_fmt)
    logger.addHandler(file_handler)

    return logger


# ─── Seeding ────────────────────────────────────────────────────────

def set_global_seed(seed: int) -> None:
    """
    Set random seeds for reproducibility across all libraries.

    Args:
        seed: Integer seed value.
    """
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass  # PyTorch not installed; SB3 will handle its own seeding


# ─── Directory Management ──────────────────────────────────────────

def ensure_dirs(config: Optional[Dict[str, Any]] = None) -> None:
    """
    Create required output directories if they don't exist.

    Args:
        config: Configuration dict. Uses DEFAULT_CONFIG if None.
    """
    if config is None:
        config = DEFAULT_CONFIG

    dirs = [
        config.get("results_dir", "results"),
        config.get("figures_dir", "figures"),
        os.path.dirname(config.get("model_save_path", "models/dqn_scheduler")),
    ]
    for d in dirs:
        if d:
            os.makedirs(d, exist_ok=True)


# ─── Results I/O ───────────────────────────────────────────────────

def save_results_csv(
    results: Dict[str, Dict[str, List[float]]],
    arrival_rates: List[float],
    filepath: str,
    metric_name: str = "avg_latency",
) -> None:
    """
    Save evaluation results to a CSV file.

    Args:
        results: Dict of {scheduler_name: {"mean": [...], "std": [...]}}.
        arrival_rates: List of arrival rates tested.
        filepath: Output CSV file path.
        metric_name: Name of the metric being saved.
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)

        # Header
        header = ["arrival_rate"]
        for name in results:
            header.extend([f"{name}_{metric_name}_mean", f"{name}_{metric_name}_std"])
        writer.writerow(header)

        # Data rows
        for i, rate in enumerate(arrival_rates):
            row = [rate]
            for name in results:
                row.append(f"{results[name]['mean'][i]:.6f}")
                row.append(f"{results[name]['std'][i]:.6f}")
            writer.writerow(row)


def save_config(config: Dict[str, Any], filepath: str) -> None:
    """
    Save configuration to a JSON file.

    Args:
        config: Configuration dictionary.
        filepath: Output JSON file path.
    """
    os.makedirs(os.path.dirname(filepath) if os.path.dirname(filepath) else ".", exist_ok=True)

    # Convert non-serializable types
    serializable = {}
    for k, v in config.items():
        if isinstance(v, np.ndarray):
            serializable[k] = v.tolist()
        elif isinstance(v, (np.integer, np.floating)):
            serializable[k] = v.item()
        else:
            serializable[k] = v

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(serializable, f, indent=2)


def load_config(filepath: str) -> Dict[str, Any]:
    """
    Load configuration from a JSON file.

    Args:
        filepath: Input JSON file path.

    Returns:
        Configuration dictionary.
    """
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


# ─── Formatting Helpers ────────────────────────────────────────────

def format_results_table(
    results: Dict[str, Dict[str, List[float]]],
    arrival_rates: List[float],
    metric_name: str = "Avg Latency",
) -> str:
    """
    Format results as a nice ASCII table for logging.

    Args:
        results: Dict of {scheduler_name: {"mean": [...], "std": [...]}}.
        arrival_rates: List of arrival rates tested.
        metric_name: Name of the metric.

    Returns:
        Formatted table string.
    """
    names = list(results.keys())
    col_width = max(len(n) for n in names) + 2

    # Header
    header = f"{'Rate':>8}"
    for name in names:
        header += f" | {name:^{col_width + 8}}"
    lines = [
        f"\n{'=' * len(header)}",
        f"  {metric_name} Comparison",
        f"{'=' * len(header)}",
        header,
        "-" * len(header),
    ]

    # Rows
    for i, rate in enumerate(arrival_rates):
        row = f"{rate:>8.2f}"
        for name in names:
            m = results[name]["mean"][i]
            s = results[name]["std"][i]
            row += f" | {m:>{col_width}.3f} ± {s:<6.3f}"
        lines.append(row)

    lines.append("=" * len(header))
    return "\n".join(lines)


def get_timestamp() -> str:
    """Return a formatted timestamp string for file naming."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")
