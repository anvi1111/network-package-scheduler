"""
train.py — DQN Training Pipeline
==================================

Trains a DQN agent on the PacketSchedulerEnv using Stable-Baselines3.
Supports configurable hyperparameters, model checkpointing, and
training curve logging.
"""

import os
import logging
from typing import Dict, Any, Optional

import numpy as np
from stable_baselines3 import DQN
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import (
    BaseCallback,
    CheckpointCallback,
    EvalCallback,
)

from env import PacketSchedulerEnv
from utils import DEFAULT_CONFIG, ensure_dirs, set_global_seed

logger = logging.getLogger("rl_packet_scheduler")


# ─── Custom Callback for Training Metrics ──────────────────────────

class TrainingMetricsCallback(BaseCallback):
    """
    Custom callback that records per-episode metrics during training.

    Tracks:
        - Episode rewards
        - Episode lengths
        - Average latency at episode end
        - Drop rate at episode end
    """

    def __init__(self, verbose: int = 0):
        super().__init__(verbose)
        self.episode_rewards = []
        self.episode_lengths = []
        self.episode_latencies = []
        self.episode_drop_rates = []
        self._current_reward = 0.0
        self._current_length = 0

    def _on_step(self) -> bool:
        """Called after every environment step during training."""
        # Accumulate reward for current episode
        self._current_reward += self.locals.get("rewards", [0])[0]
        self._current_length += 1

        # Check if episode is done
        dones = self.locals.get("dones", [False])
        if dones[0]:
            self.episode_rewards.append(self._current_reward)
            self.episode_lengths.append(self._current_length)

            # Extract info metrics from the environment
            infos = self.locals.get("infos", [{}])
            if infos and isinstance(infos[0], dict):
                self.episode_latencies.append(
                    infos[0].get("avg_latency", 0.0)
                )
                self.episode_drop_rates.append(
                    infos[0].get("drop_rate", 0.0)
                )

            # Log periodically
            n_episodes = len(self.episode_rewards)
            if n_episodes % 50 == 0:
                recent_rewards = self.episode_rewards[-50:]
                recent_latencies = self.episode_latencies[-50:]
                logger.info(
                    f"Episode {n_episodes:5d} | "
                    f"Avg Reward: {np.mean(recent_rewards):8.2f} | "
                    f"Avg Latency: {np.mean(recent_latencies):6.2f}"
                )

            self._current_reward = 0.0
            self._current_length = 0

        return True  # Continue training

    def get_metrics(self) -> Dict[str, list]:
        """Return all collected metrics."""
        return {
            "rewards": self.episode_rewards,
            "lengths": self.episode_lengths,
            "latencies": self.episode_latencies,
            "drop_rates": self.episode_drop_rates,
        }


# ─── Training Function ─────────────────────────────────────────────

def train_dqn(
    config: Optional[Dict[str, Any]] = None,
    seed: int = 42,
) -> tuple:
    """
    Train a DQN agent on the PacketSchedulerEnv.

    Args:
        config: Hyperparameter configuration dict. Uses DEFAULT_CONFIG if None.
        seed: Random seed for reproducibility.

    Returns:
        Tuple of (trained DQN model, TrainingMetricsCallback with metrics).
    """
    if config is None:
        config = DEFAULT_CONFIG.copy()

    ensure_dirs(config)
    set_global_seed(seed)

    # ── Create environment ──
    env = PacketSchedulerEnv(
        n_queues=config.get("n_queues", 4),
        max_queue_len=config.get("max_queue_len", 20),
        arrival_rate=config.get("arrival_rate", 0.6),
        link_speed=config.get("link_speed", 2),
        max_steps=config.get("max_steps", 500),
        max_age_norm=config.get("max_age_norm", 50.0),
        latency_penalty_coeff=config.get("latency_penalty_coeff", 0.3),
        drop_penalty_coeff=config.get("drop_penalty_coeff", 0.1),
        idle_penalty=config.get("idle_penalty", 0.5),
        use_class_rates=config.get("use_class_rates", False),
        trace_file=config.get("trace_file", None),
    )
    env = Monitor(env)

    # ── Create evaluation environment ──
    eval_env = PacketSchedulerEnv(
        n_queues=config.get("n_queues", 4),
        max_queue_len=config.get("max_queue_len", 20),
        arrival_rate=config.get("arrival_rate", 0.6),
        link_speed=config.get("link_speed", 2),
        max_steps=config.get("max_steps", 500),
        max_age_norm=config.get("max_age_norm", 50.0),
        latency_penalty_coeff=config.get("latency_penalty_coeff", 0.3),
        drop_penalty_coeff=config.get("drop_penalty_coeff", 0.1),
        idle_penalty=config.get("idle_penalty", 0.5),
        use_class_rates=config.get("use_class_rates", False),
        trace_file=config.get("trace_file", None),
    )
    eval_env = Monitor(eval_env)

    # ── Build DQN model ──
    model = DQN(
        policy="MlpPolicy",
        env=env,
        learning_rate=config.get("learning_rate", 1e-3),
        buffer_size=config.get("buffer_size", 50_000),
        learning_starts=config.get("learning_starts", 1000),
        batch_size=config.get("batch_size", 64),
        gamma=config.get("gamma", 0.95),
        train_freq=config.get("train_freq", 4),
        target_update_interval=config.get("target_update_interval", 500),
        exploration_fraction=config.get("exploration_fraction", 0.3),
        exploration_final_eps=config.get("exploration_final_eps", 0.05),
        verbose=0,
        seed=seed,
    )

    # ── Callbacks ──
    metrics_callback = TrainingMetricsCallback()

    model_dir = os.path.dirname(config.get("model_save_path", "models/dqn_scheduler"))
    checkpoint_cb = CheckpointCallback(
        save_freq=10_000,
        save_path=model_dir,
        name_prefix="dqn_checkpoint",
    )

    eval_cb = EvalCallback(
        eval_env,
        best_model_save_path=model_dir,
        log_path=config.get("results_dir", "results"),
        eval_freq=5_000,
        n_eval_episodes=5,
        deterministic=True,
        verbose=0,
    )

    total_timesteps = config.get("total_timesteps", 100_000)

    logger.info("=" * 60)
    logger.info("  DQN Training Started")
    logger.info("=" * 60)
    logger.info(f"  Total timesteps:    {total_timesteps:,}")
    logger.info(f"  Learning rate:      {config.get('learning_rate', 1e-3)}")
    logger.info(f"  Buffer size:        {config.get('buffer_size', 50_000):,}")
    logger.info(f"  Batch size:         {config.get('batch_size', 64)}")
    logger.info(f"  Gamma:              {config.get('gamma', 0.95)}")
    logger.info(f"  Arrival rate:       {config.get('arrival_rate', 0.6)}")
    logger.info(f"  Seed:               {seed}")
    logger.info("-" * 60)

    # ── Train ──
    # Enable progress bar only if tqdm and rich are available
    try:
        import tqdm  # noqa: F401
        import rich  # noqa: F401
        use_progress_bar = True
    except ImportError:
        use_progress_bar = False
        logger.info("Install tqdm and rich for a progress bar: pip install tqdm rich")

    model.learn(
        total_timesteps=total_timesteps,
        callback=[metrics_callback, checkpoint_cb, eval_cb],
        progress_bar=use_progress_bar,
    )

    # ── Save final model ──
    save_path = config.get("model_save_path", "models/dqn_scheduler")
    model.save(save_path)
    logger.info(f"Model saved to {save_path}.zip")

    return model, metrics_callback


def load_model(model_path: str) -> DQN:
    """
    Load a previously trained DQN model.

    Args:
        model_path: Path to the saved model (without .zip extension).

    Returns:
        Loaded DQN model.
    """
    logger.info(f"Loading model from {model_path}")
    return DQN.load(model_path)


# ─── Entry Point for Standalone Training ───────────────────────────

if __name__ == "__main__":
    from utils import setup_logging

    setup_logging()
    model, metrics = train_dqn()
    print(f"\nTraining complete. Total episodes: {len(metrics.episode_rewards)}")
    print(f"Final avg reward (last 50): {np.mean(metrics.episode_rewards[-50:]):.2f}")
