"""
evaluate.py — Evaluation & Comparison Module
==============================================

Evaluates RL agent vs baseline schedulers across multiple traffic loads.
"""

import os
import logging
from typing import Dict, Any, Optional, List, Callable, Tuple

import numpy as np
from stable_baselines3 import DQN

from env import PacketSchedulerEnv
from baselines import FIFOScheduler, RoundRobinScheduler, StrictPriorityScheduler
from utils import DEFAULT_CONFIG, ensure_dirs, save_results_csv, format_results_table, set_global_seed

logger = logging.getLogger("rl_packet_scheduler")


def evaluate_policy(policy_fn, n_episodes=10, max_steps=500, arrival_rate=0.6, env_kwargs=None):
    """Run a policy for n_episodes, return metrics dict with (mean, std) tuples."""
    if env_kwargs is None:
        env_kwargs = {}
    latencies, drop_rates, sents, drops = [], [], [], []
    for ep in range(n_episodes):
        env = PacketSchedulerEnv(max_steps=max_steps, arrival_rate=arrival_rate, **env_kwargs)
        obs, _ = env.reset(seed=ep)
        done = False
        while not done:
            action = policy_fn(obs)
            obs, _, terminated, truncated, info = env.step(action)
            done = terminated or truncated
        latencies.append(info["avg_latency"])
        drop_rates.append(info["drop_rate"])
        sents.append(info["sent"])
        drops.append(info["dropped"])
    return {
        "avg_latency": (float(np.mean(latencies)), float(np.std(latencies))),
        "drop_rate": (float(np.mean(drop_rates)), float(np.std(drop_rates))),
        "total_sent": (float(np.mean(sents)), float(np.std(sents))),
        "total_dropped": (float(np.mean(drops)), float(np.std(drops))),
    }


def evaluate_baseline(scheduler_class, n_episodes=10, max_steps=500, arrival_rate=0.6, env_kwargs=None):
    """Evaluate a baseline scheduler that reads env.queues directly."""
    if env_kwargs is None:
        env_kwargs = {}
    latencies, drop_rates, sents, drops = [], [], [], []
    for ep in range(n_episodes):
        env = PacketSchedulerEnv(max_steps=max_steps, arrival_rate=arrival_rate, **env_kwargs)
        scheduler = scheduler_class(env)
        if hasattr(scheduler, "reset"):
            scheduler.reset()
        obs, _ = env.reset(seed=ep)
        done = False
        while not done:
            action = scheduler.act(obs)
            obs, _, terminated, truncated, info = env.step(action)
            done = terminated or truncated
        latencies.append(info["avg_latency"])
        drop_rates.append(info["drop_rate"])
        sents.append(info["sent"])
        drops.append(info["dropped"])
    return {
        "avg_latency": (float(np.mean(latencies)), float(np.std(latencies))),
        "drop_rate": (float(np.mean(drop_rates)), float(np.std(drop_rates))),
        "total_sent": (float(np.mean(sents)), float(np.std(sents))),
        "total_dropped": (float(np.mean(drops)), float(np.std(drops))),
    }


def run_comparison(config=None, model=None, model_path=None, seed=42):
    """
    Compare RL agent vs baselines across arrival rates.
    Returns: {metric: {scheduler: {"mean": [...], "std": [...]}}}.
    """
    if config is None:
        config = DEFAULT_CONFIG.copy()
    ensure_dirs(config)
    set_global_seed(seed)

    arrival_rates = config.get("arrival_rates", [0.3, 0.45, 0.6, 0.75, 0.9])
    n_episodes = config.get("n_eval_episodes", 10)
    max_steps = config.get("max_steps", 500)
    scheduler_names = ["RL (DQN)", "FIFO", "Round Robin", "Strict Priority"]
    metrics = ["avg_latency"]

    all_results = {m: {n: {"mean": [], "std": []} for n in scheduler_names} for m in metrics}

    # Load RL model
    rl_available = False
    if model is not None:
        rl_available = True
    elif model_path:
        try:
            model = DQN.load(model_path)
            rl_available = True
            logger.info(f"Loaded model from {model_path}")
        except Exception as e:
            logger.warning(f"Could not load model: {e}")
    else:
        default_path = config.get("model_save_path", "models/dqn_scheduler")
        try:
            model = DQN.load(default_path)
            rl_available = True
            logger.info(f"Loaded model from {default_path}")
        except Exception:
            logger.warning("No trained model found. Train first with: python train.py")

    logger.info("=" * 60)
    logger.info("  Evaluation Experiment")
    logger.info(f"  Rates: {arrival_rates} | Episodes: {n_episodes}")
    logger.info("=" * 60)

    env_kwargs = {
        "n_queues": config.get("n_queues", 4),
        "max_queue_len": config.get("max_queue_len", 20),
        "max_age_norm": config.get("max_age_norm", 50.0),
        "latency_penalty_coeff": config.get("latency_penalty_coeff", 0.3),
        "drop_penalty_coeff": config.get("drop_penalty_coeff", 0.1),
        "idle_penalty": config.get("idle_penalty", 0.5),
        "trace_file": config.get("trace_file", None),
    }

    baseline_map = {
        "FIFO": FIFOScheduler,
        "Round Robin": RoundRobinScheduler,
        "Strict Priority": StrictPriorityScheduler,
    }

    for rate in arrival_rates:
        logger.info(f"\n--- Arrival rate = {rate:.2f} ---")

        # RL Agent
        if rl_available:
            def rl_policy(obs, _m=model):
                a, _ = _m.predict(obs, deterministic=True)
                return int(a)
            rl_m = evaluate_policy(rl_policy, n_episodes, max_steps, rate, env_kwargs)
        else:
            rl_m = {m: (0.0, 0.0) for m in metrics}

        for m in metrics:
            all_results[m]["RL (DQN)"]["mean"].append(rl_m[m][0])
            all_results[m]["RL (DQN)"]["std"].append(rl_m[m][1])
        logger.info(f"  RL: lat={rl_m['avg_latency'][0]:.3f}±{rl_m['avg_latency'][1]:.3f}")

        # Baselines
        for name, cls in baseline_map.items():
            bm = evaluate_baseline(cls, n_episodes, max_steps, rate, env_kwargs)
            for m in metrics:
                all_results[m][name]["mean"].append(bm[m][0])
                all_results[m][name]["std"].append(bm[m][1])
            logger.info(f"  {name}: lat={bm['avg_latency'][0]:.3f}±{bm['avg_latency'][1]:.3f}")

    # Save CSV results
    results_dir = config.get("results_dir", "results")
    for m in metrics:
        csv_path = os.path.join(results_dir, f"{m}_comparison.csv")
        save_results_csv(all_results[m], arrival_rates, csv_path, metric_name=m)
        logger.info(f"Saved {csv_path}")

    # Print tables
    for m in metrics:
        logger.info(format_results_table(all_results[m], arrival_rates, metric_name=m))

    return all_results


if __name__ == "__main__":
    from utils import setup_logging
    setup_logging()
    run_comparison()
