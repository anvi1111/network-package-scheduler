"""
baselines.py — Traditional Packet Scheduling Algorithms
========================================================

Implements three classical scheduling baselines:
    1. FIFO (First In, First Out) — serves the globally oldest packet
    2. Round Robin — cycles through non-empty queues equally
    3. Strict Priority — always serves the highest-priority non-empty queue
"""

from typing import Any
import numpy as np


class FIFOScheduler:
    """
    Global FIFO (First In, First Out) Scheduler.

    Selects the queue containing the packet with the highest age
    (i.e., the globally oldest packet across all queues).
    Fair in terms of arrival time but ignores traffic priority.
    """

    def __init__(self, env: Any):
        """
        Args:
            env: A PacketSchedulerEnv instance.
        """
        self.env = env

    def act(self, obs: np.ndarray) -> int:
        """
        Select the queue with the oldest packet.

        Args:
            obs: Current observation (unused; we read from env.queues directly).

        Returns:
            Queue index to serve.
        """
        oldest_age = -1
        choice = 0
        for q in range(self.env.n_queues):
            if self.env.queues[q] and self.env.queues[q][0] > oldest_age:
                oldest_age = self.env.queues[q][0]
                choice = q
        return choice

    def reset(self) -> None:
        """Reset scheduler state (FIFO is stateless)."""
        pass


class RoundRobinScheduler:
    """
    Round Robin Scheduler.

    Cycles through queues in order, serving one packet from each
    non-empty queue before moving on. Provides fair bandwidth
    allocation but ignores traffic priority.
    """

    def __init__(self, env: Any):
        """
        Args:
            env: A PacketSchedulerEnv instance.
        """
        self.env = env
        self.ptr = 0  # Current position in the round-robin cycle

    def act(self, obs: np.ndarray) -> int:
        """
        Select the next non-empty queue in round-robin order.

        Args:
            obs: Current observation (unused; we read from env.queues directly).

        Returns:
            Queue index to serve.
        """
        for _ in range(self.env.n_queues):
            q = self.ptr % self.env.n_queues
            self.ptr += 1
            if self.env.queues[q]:
                return q
        return 0  # fallback: all queues empty

    def reset(self) -> None:
        """Reset the round-robin pointer."""
        self.ptr = 0


class StrictPriorityScheduler:
    """
    Strict Priority Scheduler.

    Always serves the highest-priority non-empty queue first.
    Queue 0 (voice) has highest priority, queue 3 (bulk) has lowest.
    Optimal for minimizing latency of high-priority traffic but can
    starve lower-priority queues under heavy load.
    """

    def __init__(self, env: Any):
        """
        Args:
            env: A PacketSchedulerEnv instance.
        """
        self.env = env
        # Priority order: voice (0) > video (1) > web (2) > bulk (3)
        self.priority_order = list(range(env.n_queues))

    def act(self, obs: np.ndarray) -> int:
        """
        Select the highest-priority non-empty queue.

        Args:
            obs: Current observation (unused; we read from env.queues directly).

        Returns:
            Queue index to serve.
        """
        for q in self.priority_order:
            if self.env.queues[q]:
                return q
        return 0  # fallback: all queues empty

    def reset(self) -> None:
        """Reset scheduler state (Strict Priority is stateless)."""
        pass
