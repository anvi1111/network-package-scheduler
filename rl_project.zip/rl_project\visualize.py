"""
visualize.py — Plotting & Visualization Module
================================================

Generates publication-quality figures:
    1. Latency comparison across arrival rates (RL vs baselines)
    2. Drop rate comparison across arrival rates
    3. Training performance curves (reward, latency over episodes)
"""

import os
import logging
from typing import Dict, List, Optional, Any

import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# Use non-interactive backend for VS Code / headless environments
matplotlib.use("Agg")

logger = logging.getLogger("rl_packet_scheduler")

# ─── Plot Style Configuration ──────────────────────────────────────

SCHEDULER_STYLES = {
    "RL (DQN)": {"color": "#1a73e8", "ls": "-", "lw": 2.5, "marker": "o", "ms": 7},
    "FIFO": {"color": "#636363", "ls": "--", "lw": 1.8, "marker": "s", "ms": 6},
    "Round Robin": {"color": "#43a047", "ls": "-.", "lw": 1.8, "marker": "^", "ms": 7},
    "Strict Priority": {"color": "#e53935", "ls": ":", "lw": 1.8, "marker": "D", "ms": 6},
}

def _apply_plot_style():
    """Apply a clean, publication-ready matplotlib style."""
    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 11,
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "legend.fontsize": 10,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "figure.dpi": 150,
        "savefig.dpi": 200,
        "savefig.bbox": "tight",
        "axes.grid": True,
        "grid.alpha": 0.3,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })


# ─── Comparison Plots ──────────────────────────────────────────────

def plot_metric_comparison(
    results: Dict[str, Dict[str, List[float]]],
    arrival_rates: List[float],
    metric_name: str = "Average Latency",
    ylabel: str = "Average Packet Latency (steps)",
    save_path: Optional[str] = None,
    title: Optional[str] = None,
) -> None:
    """
    Plot a metric comparison across arrival rates for all schedulers.

    Args:
        results: {scheduler_name: {"mean": [...], "std": [...]}}.
        arrival_rates: X-axis values.
        metric_name: Name used in title if title is None.
        ylabel: Y-axis label.
        save_path: File path to save the figure. If None, uses default.
        title: Custom plot title.
    """
    _apply_plot_style()
    fig, ax = plt.subplots(figsize=(9, 5.5))

    for name, data in results.items():
        style = SCHEDULER_STYLES.get(name, {"color": "#999", "ls": "-", "lw": 1.5, "marker": "x", "ms": 5})
        means = np.array(data["mean"])
        stds = np.array(data["std"])

        ax.plot(
            arrival_rates, means,
            label=name,
            color=style["color"],
            ls=style["ls"],
            lw=style["lw"],
            marker=style["marker"],
            markersize=style["ms"],
            zorder=5 if name == "RL (DQN)" else 3,
        )
        ax.fill_between(
            arrival_rates,
            means - stds,
            means + stds,
            alpha=0.12,
            color=style["color"],
        )

    if title is None:
        title = f"RL Packet Scheduling vs Baselines — {metric_name}"
    ax.set_title(title, fontweight="bold", pad=12)
    ax.set_xlabel("Arrival Rate (packets/queue/step)")
    ax.set_ylabel(ylabel)
    ax.legend(framealpha=0.9, edgecolor="#ccc")

    if save_path is None:
        save_path = f"figures/{metric_name.lower().replace(' ', '_')}_comparison.png"
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    fig.savefig(save_path)
    plt.close(fig)
    logger.info(f"Figure saved: {save_path}")


def plot_all_comparisons(
    all_results: Dict[str, Dict[str, Dict[str, List[float]]]],
    arrival_rates: List[float],
    figures_dir: str = "figures",
) -> None:
    """
    Generate all comparison plots from evaluation results.

    Args:
        all_results: {metric: {scheduler: {"mean": [...], "std": [...]}}}.
        arrival_rates: X-axis values.
        figures_dir: Directory to save figures.
    """
    # Latency comparison
    if "avg_latency" in all_results:
        plot_metric_comparison(
            all_results["avg_latency"],
            arrival_rates,
            metric_name="Average Latency",
            ylabel="Average Packet Latency (steps)",
            save_path=os.path.join(figures_dir, "latency_comparison.png"),
        )

    # Drop rate comparison
    if "drop_rate" in all_results:
        plot_metric_comparison(
            all_results["drop_rate"],
            arrival_rates,
            metric_name="Packet Drop Rate",
            ylabel="Packet Drop Rate",
            save_path=os.path.join(figures_dir, "drop_rate_comparison.png"),
        )


# ─── Training Curves ───────────────────────────────────────────────

def plot_training_curves(
    metrics: Dict[str, list],
    save_dir: str = "figures",
    window: int = 50,
) -> None:
    """
    Plot training performance curves with smoothing.

    Args:
        metrics: Dict from TrainingMetricsCallback.get_metrics().
            Expected keys: "rewards", "latencies", "drop_rates".
        save_dir: Directory to save figures.
        window: Smoothing window size for rolling average.
    """
    _apply_plot_style()
    os.makedirs(save_dir, exist_ok=True)

    def smooth(data, w):
        if len(data) < w:
            return data
        return np.convolve(data, np.ones(w) / w, mode="valid")

    # ── Reward curve ──
    if "rewards" in metrics and metrics["rewards"]:
        fig, ax = plt.subplots(figsize=(9, 4.5))
        rewards = np.array(metrics["rewards"])
        episodes = np.arange(len(rewards))

        ax.plot(episodes, rewards, alpha=0.2, color="#1a73e8", linewidth=0.5)
        smoothed = smooth(rewards, window)
        ax.plot(
            np.arange(len(smoothed)) + window // 2,
            smoothed,
            color="#1a73e8",
            linewidth=2,
            label=f"Smoothed (window={window})",
        )
        ax.set_title("Training Reward per Episode", fontweight="bold", pad=12)
        ax.set_xlabel("Episode")
        ax.set_ylabel("Total Episode Reward")
        ax.legend()

        path = os.path.join(save_dir, "training_reward.png")
        fig.savefig(path)
        plt.close(fig)
        logger.info(f"Figure saved: {path}")

    # ── Latency curve ──
    if "latencies" in metrics and metrics["latencies"]:
        fig, ax = plt.subplots(figsize=(9, 4.5))
        latencies = np.array(metrics["latencies"])
        episodes = np.arange(len(latencies))

        ax.plot(episodes, latencies, alpha=0.2, color="#e53935", linewidth=0.5)
        smoothed = smooth(latencies, window)
        ax.plot(
            np.arange(len(smoothed)) + window // 2,
            smoothed,
            color="#e53935",
            linewidth=2,
            label=f"Smoothed (window={window})",
        )
        ax.set_title("Average Latency During Training", fontweight="bold", pad=12)
        ax.set_xlabel("Episode")
        ax.set_ylabel("Average Packet Latency")
        ax.legend()

        path = os.path.join(save_dir, "training_latency.png")
        fig.savefig(path)
        plt.close(fig)
        logger.info(f"Figure saved: {path}")

    # ── Drop rate curve ──
    if "drop_rates" in metrics and metrics["drop_rates"]:
        fig, ax = plt.subplots(figsize=(9, 4.5))
        drop_rates = np.array(metrics["drop_rates"])
        episodes = np.arange(len(drop_rates))

        ax.plot(episodes, drop_rates, alpha=0.2, color="#43a047", linewidth=0.5)
        smoothed = smooth(drop_rates, window)
        ax.plot(
            np.arange(len(smoothed)) + window // 2,
            smoothed,
            color="#43a047",
            linewidth=2,
            label=f"Smoothed (window={window})",
        )
        ax.set_title("Packet Drop Rate During Training", fontweight="bold", pad=12)
        ax.set_xlabel("Episode")
        ax.set_ylabel("Drop Rate")
        ax.legend()

        path = os.path.join(save_dir, "training_drop_rate.png")
        fig.savefig(path)
        plt.close(fig)
        logger.info(f"Figure saved: {path}")
